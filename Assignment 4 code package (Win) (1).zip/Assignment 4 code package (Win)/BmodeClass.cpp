#include "BmodeClass.h"

BmodeClass::BmodeClass()
{

}

BmodeClass::BmodeClass(imageParam *params,dataBuffer *data,int numline)
{

}

BmodeClass::~BmodeClass()
{

}

float *BmodeClass::createScanline(int numPixel)
{

}

void BmodeClass::beamform()
{

}

void BmodeClass::getScanline(float *data)
{

}

void BmodeClass::deleteScanline()
{
    
}